
About:
This is a Flappy Bird clone that was recreated in Java.
JRE is required to run this program.

Credits:
Clone created by Eric Feng

Assets created by sourabhv & Flappy Bird

Sources:
https://github.com/sourabhv/FlapPyBird
https://www.spriters-resource.com/mobile/flappybird/sheet/59894/